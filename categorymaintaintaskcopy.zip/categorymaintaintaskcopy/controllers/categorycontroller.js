const Category=require('../models/category')



exports.categorymanagement=(req,res)=>{
    const loginname=req.session.loginname
    res.render('categorymanagement.ejs',{loginname})
}

exports.addcategoryform=(req,res)=>{
    const loginname=req.session.loginname
    res.render('addcategoryform.ejs',{loginname})
}
exports.addcategory=(req,res)=>{
    //console.log(req.body)
    const {category}=req.body
    const record=new Category({category:category})
    console.log(record)
}