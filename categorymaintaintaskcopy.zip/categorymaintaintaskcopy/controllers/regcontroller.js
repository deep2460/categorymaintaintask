const Reg=require('../models/reg')




exports.loginpage=(req,res)=>{
    res.render('adminlogin.ejs',{message:''})
}
exports.logincheck=async(req,res)=>{
    //console.log(req.body)
    const{username,password}=req.body
    const record=await Reg.findOne({username:username})
    //console.log(record)
    if(record!==null){
        if(record.password==password){
            req.session.isAuth=true
            req.session.loginname=username
        res.redirect('/admin/dashboard')
        }else{
            res.render('adminlogin.ejs',{message:'password incorrrect'})
        }
    }else{
        res.render('adminlogin.ejs',{message:'username incorrrect'})
    }
}

exports.admindashboard=(req,res)=>{
    //console.log(req.session)
    const loginname=req.session.loginname
    res.render('admindashboard.ejs',{loginname})
}

exports.logout=(req,res)=>{
    req.session.destroy()
    res.redirect('/admin/')
}