const mongoose=require('mongoose')

const regSchema=mongoose.Schema({
    username:String,
    password:Number
})





module.exports=mongoose.model('reg',regSchema)