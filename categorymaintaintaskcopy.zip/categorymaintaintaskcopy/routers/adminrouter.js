const router=require('express').Router()
const regc=require('../controllers/regcontroller')
const categoryc=require('../controllers/categorycontroller')

router.get('/',regc.loginpage)
router.post('/',regc.logincheck)
router.get('/dashboard',regc.admindashboard)
router.get('/logout',regc.logout)
router.get('/admincategorymanagement',categoryc.categorymanagement)
router.get('/addcategoryform',categoryc.addcategoryform)
router.post('/addcategoryform',categoryc.addcategory)










module.exports=router